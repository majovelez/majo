#######################################COURSE PROJECT 1#######################################
######DATA
#Firstly, I was open the base in excel and then, I deleted the information that does not correspond to 2007-02-01 and 2007-02-02
install.packages("readr")
library(readr)
baselimpia <- read_delim("Coursera R/baselimpia.txt", ";", escape_double = FALSE, trim_ws = TRUE)
getwd()
dir()
ls()
View(baselimpia)
names(baselimpia)
#[1] "Date"                  "Time"                  "Global_active_power"  
#[4] "Global_reactive_power" "Voltage"               "Global_intensity"     
#[7] "Sub_metering_1"        "Sub_metering_2"        "Sub_metering_3"